"""
Sayless - AI Git Copilot / Autopilot
"""

__version__ = "0.2.0"

"""
Sayless CLI module
""" 